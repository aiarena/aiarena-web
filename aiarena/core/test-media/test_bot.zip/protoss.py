from sc2.constants import *


class ProtossManager():
    """Protoss Race Manager"""
    def __init__(self, bot=None):
        self.bot = bot
        self.ramp_supply_built = False
        self.coreboosted = None
        self.workerscout = None

    async def Run(self):
        """Runs on every GameStep"""
        await self.Macro()
        await self.Buffs()
        await self.Micro()

    async def Macro(self):
        """Macro Routine"""
        await self.bot.unitmanager.createBuilding("Gateway", 1, self.bot.hq_location, 10)
        await self.bot.unitmanager.createUnit("Zealot", 1)

        # Build a wall if enemy is attacking early
        if self.bot.data_attacktime:
            if self.bot.data_attacktime <= 180:
                await self.createWall()
        else:
            # Build a wall if we dont know when enemy is attacking
            await self.createWall()

        # VS Protoss
        if str(self.bot.race_enemy) == 'Protoss':
            if self.bot.units(UnitTypeId.GATEWAY) or self.bot.units(UnitTypeId.WARPGATE):
                await self.bot.ressources.createGas()
                await self.bot.unitmanager.trainSkill("RESEARCH_WARPGATE")

            if self.bot.units(UnitTypeId.CYBERNETICSCORE):
                await self.bot.unitmanager.createBuilding("Gateway", 4, self.bot.hq_location, 15)

            await self.bot.unitmanager.createUnit("Stalker", 50)
            if self.bot.units(UnitTypeId.STALKER):
                await self.bot.unitmanager.trainSkill("RESEARCH_BLINK")

        # VS Terran
        elif str(self.bot.race_enemy) == 'Terran':
            await self.bot.unitmanager.createBuilding("Gateway", 4, self.bot.hq_location, 10)

            if self.bot.units(UnitTypeId.GATEWAY) or self.bot.units(UnitTypeId.WARPGATE):
                await self.bot.ressources.createGas()
                await self.createWall()
                await self.bot.unitmanager.trainSkill("RESEARCH_WARPGATE")

            await self.bot.unitmanager.createUnit("Stalker", 15)
            if self.bot.units(UnitTypeId.STALKER):
                await self.bot.unitmanager.trainSkill("RESEARCH_BLINK")
                await self.bot.unitmanager.createUnit("Sentry", 3)

            await self.bot.unitmanager.createUnit("Immortal", 15)

        # VS Zerg
        elif str(self.bot.race_enemy) == 'Zerg':
            await self.bot.unitmanager.createBuilding("Gateway", 4, self.bot.hq_location, 10)

            if self.bot.units(UnitTypeId.GATEWAY) or self.bot.units(UnitTypeId.WARPGATE):
                await self.bot.ressources.createGas()
                await self.createWall()
                await self.bot.unitmanager.trainSkill("RESEARCH_WARPGATE")

            await self.bot.unitmanager.createUnit("Stalker", 15)
            if self.bot.units(UnitTypeId.STALKER):
                await self.bot.unitmanager.trainSkill("RESEARCH_BLINK")
                await self.bot.unitmanager.createUnit("Sentry", 3)

            await self.bot.unitmanager.createUnit("Colossus", 5)

        # Send a worker scout
        if self.bot.units(self.bot.worker).ready and not self.workerscout:
            worker = self.bot.units(self.bot.worker).ready.first
            if worker:
                self.workerscout = True
                await self.bot.warmanager.scout(worker)

        # Check if expansion is needed
        if (self.bot.units(self.bot.worker).ready.amount / 1.1) >= self.bot.neededworkers:
            await self.bot.warmanager.expand()

        if int(self.bot.time) >= 300 and self.bot.units(self.bot.townhall).amount == 1:
            await self.bot.warmanager.expand()
        if int(self.bot.time) >= 600 and self.bot.units(self.bot.townhall).amount <= 3:
            await self.bot.warmanager.expand()

    async def Micro(self):
        """Micro Routine"""
        # Stalker Micro
        stalkers = self.bot.units(UnitTypeId.STALKER).ready
        if stalkers:
            for stalker in stalkers:
                enemies = self.bot.known_enemy_units.closer_than(30, stalker)

                if enemies:
                    next_enemy = enemies.closest_to(stalker)
                    if not next_enemy:
                        break

                    distance2enemy = stalker.position.distance_to(next_enemy.position)
                    if distance2enemy < 20:
                        self.bot.microActions.append(stalker.attack(next_enemy))

                    nx = self.bot.townhalls.ready.closest_to(stalker)
                    if not nx:
                        break

                    nxdistance = stalker.position.distance_to(nx.position)
                    if nxdistance < 10:
                        break

                    if distance2enemy < self.bot.techtree.get_unit_weaponrange(UnitTypeId.STALKER):
                        if (next_enemy.name != 'Probe') or (next_enemy.name != 'SCV') or (
                                next_enemy.name != 'Drone'):
                            abilities = await self.bot.get_available_abilities(stalker)
                            if (AbilityId.EFFECT_BLINK_STALKER in abilities) and (stalker.health_percentage < 25):
                                if not next_enemy.position:
                                    break
                                blinkposition = stalker.position.towards(next_enemy.position, -8)
                                if not blinkposition:
                                    break
                                if stalker.position != next_enemy.position:
                                    if self.bot.in_pathing_grid(blinkposition) and self.bot.is_visible(blinkposition) or (blinkposition == stalker.position):
                                        self.bot.microActions.append(stalker(AbilityId.EFFECT_BLINK_STALKER, blinkposition))
                            elif distance2enemy < 2:
                                break
                            else:
                                moveposition = stalker.position.towards(next_enemy.position, -1)
                                if not moveposition or not self.bot.in_pathing_grid(moveposition):
                                    break
                                self.bot.microActions.append(stalker.move(moveposition))

        # Sentry Micro
        sentries = self.bot.units(UnitTypeId.SENTRY).ready
        if sentries:
            for sentry in sentries:
                enemies = self.bot.known_enemy_units.closer_than(30, sentry)

                if enemies:
                    next_enemy = enemies.closest_to(sentry)
                    if not next_enemy:
                        break
                    if (next_enemy.name == 'Probe') or (next_enemy.name == 'SCV') or (next_enemy.name == 'Drone'):
                        break

                    distance2enemy = sentry.position.distance_to(next_enemy.position)

                    ramp = self.bot.main_base_ramp.top_center.position
                    blockpos = ramp.position.towards(self.bot.firstexpansion, 2)
                    enemydistance2ramp = next_enemy.position.distance_to(ramp)
                    sentrydistance2ramp = sentry.position.distance_to(ramp)

                    # Block Ramp
                    if (next_enemy.type_id == UnitTypeId.ZEALOT or next_enemy.type_id == UnitTypeId.MARINE or next_enemy.type_id == UnitTypeId.ZERGLING) and enemydistance2ramp <= 10 and sentry.energy >= 50:
                        self.bot.microActions.append(sentry(AbilityId.FORCEFIELD_FORCEFIELD, blockpos))
                        break

                    # Shield
                    if not sentry.has_buff(BuffId.GUARDIANSHIELD) and (sentry.energy >= 75) and (distance2enemy < 8):
                        if (not next_enemy.name == 'Probe') or (not next_enemy.name == 'SCV') or (
                        not next_enemy.name == 'Drone'):
                            self.bot.microActions.append(sentry(AbilityId.GUARDIANSHIELD_GUARDIANSHIELD))
                            break
                    else:
                        nx = self.bot.townhalls.ready.closest_to(sentry)
                        if not nx:
                            break

                        nxdistance = sentry.position.distance_to(nx.position)
                        if (nxdistance < 10) or (distance2enemy < 2):
                            break

                        if distance2enemy < self.bot.techtree.get_unit_weaponrange(UnitTypeId.SENTRY):
                            if (next_enemy.name != 'Probe') or (next_enemy.name != 'SCV') or (next_enemy.name != 'Drone'):
                                moveposition = sentry.position.towards(next_enemy.position, -1)
                                if not moveposition or not self.bot.in_pathing_grid(moveposition):
                                    break
                                self.bot.microActions.append(sentry.move(moveposition))

        # Immortals Micro
        immortals = self.bot.units(UnitTypeId.IMMORTAL).ready
        if immortals:
            for immortal in immortals:
                enemies = self.bot.known_enemy_units.closer_than(30, immortal)

                for e in enemies:
                    if e.is_flying:
                        enemies.remove(e)

                if enemies:
                    next_enemy = enemies.closest_to(immortal)
                    if not next_enemy:
                        break

                    distance2enemy = immortal.position.distance_to(next_enemy.position)
                    if distance2enemy < 20:
                        self.bot.microActions.append(immortal.attack(next_enemy))

                    nx = self.bot.units(UnitTypeId.NEXUS).ready.closest_to(immortal)
                    if not nx:
                        break

                    nxdistance = immortal.position.distance_to(nx.position)
                    if nxdistance < 10:
                        break

                    if distance2enemy < 2:
                        break

                    if distance2enemy < 5:
                        if (next_enemy.name != 'Probe') or (next_enemy.name != 'SCV') or (next_enemy.name != 'Drone'):
                            moveposition = immortal.position.towards(next_enemy.position, -1)
                            if not moveposition or not self.bot.in_pathing_grid(moveposition):
                                break
                            self.bot.microActions.append(immortal.move(moveposition))

        # Colossus Micro
        colossuses = self.bot.units(UnitTypeId.COLOSSUS).ready
        if colossuses:
            for colossus in colossuses:
                enemies = self.bot.known_enemy_units.closer_than(30, colossus)
                for e in enemies:
                    if e.is_flying:
                        enemies.remove(e)

                if enemies:
                    next_enemy = enemies.closest_to(colossus)
                    if not next_enemy:
                        break

                    distance2enemy = colossus.position.distance_to(next_enemy.position)
                    if distance2enemy < 20:
                        self.bot.microActions.append(colossus.attack(next_enemy))

                    nx = self.bot.units(UnitTypeId.NEXUS).ready.closest_to(colossus)
                    if not nx:
                        break

                    nxdistance = colossus.position.distance_to(nx.position)
                    if nxdistance < 5:
                        break

                    if distance2enemy < 1:
                        break

                    # TODO: Replace this with an ability check
                    #if self.exlance_started:
                    #    movedistance = 9
                    #else:
                    #    movedistance = 7
                    movedistance = 7

                    if distance2enemy < movedistance:
                        if (next_enemy.name != 'Probe') or (next_enemy.name != 'SCV') or (next_enemy.name != 'Drone'):
                            moveposition = colossus.position.towards(next_enemy.position, -1)
                            if not moveposition or not self.bot.in_pathing_grid(moveposition):
                                break
                            self.bot.microActions.append(colossus.move(moveposition))

        # Observer Micro
        observers = self.bot.units(UnitTypeId.OBSERVER).ready
        observersiege = self.bot.units(UnitTypeId.OBSERVERSIEGEMODE).ready
        allobservers = observers | observersiege

        if allobservers:
            for observer in allobservers:
                enemies = self.bot.known_enemy_units.closer_than(15, observer)
                if enemies:
                    if enemies.amount > 6:
                        abilities = await self.bot.get_available_abilities(observer)
                        if AbilityId.MORPH_SURVEILLANCEMODE in abilities:
                            if self.bot.can_afford(AbilityId.MORPH_SURVEILLANCEMODE):
                                self.bot.microActions.append(observer(AbilityId.MORPH_SURVEILLANCEMODE))
                                break
                    else:
                        abilities = await self.bot.get_available_abilities(observer)
                        if AbilityId.MORPH_OBSERVERMODE in abilities:
                            if self.bot.can_afford(AbilityId.MORPH_OBSERVERMODE):
                                self.bot.microActions.append(observer(AbilityId.MORPH_OBSERVERMODE))
                                break
                else:
                    abilities = await self.bot.get_available_abilities(observer)
                    if AbilityId.MORPH_OBSERVERMODE in abilities:
                        if self.bot.can_afford(AbilityId.MORPH_OBSERVERMODE):
                            self.bot.microActions.append(observer(AbilityId.MORPH_OBSERVERMODE))
                            break
                if observer.type_id == UnitTypeId.OBSERVER:
                    await self.bot.warmanager.scout(observer, True, True)

    async def Buffs(self):
        """Buff Routine"""
        # Morph Gateway to Warpgate if possible
        if self.bot.units(UnitTypeId.GATEWAY).ready:
            gateways = self.bot.units(UnitTypeId.GATEWAY).ready
            for gateway in gateways:
                abilities = await self.bot.get_available_abilities(gateway)
                if AbilityId.MORPH_WARPGATE in abilities and self.bot.can_afford(AbilityId.MORPH_WARPGATE):
                    self.bot.microActions.append(gateway(AbilityId.MORPH_WARPGATE))

        # Chronoboost
        for hq in self.bot.townhalls.ready:
            # Boost Cyber Core
            if self.bot.units(UnitTypeId.CYBERNETICSCORE).ready.exists and not self.coreboosted:
                ccore = self.bot.units(UnitTypeId.CYBERNETICSCORE).ready.first
                if not ccore.has_buff(BuffId.CHRONOBOOSTENERGYCOST):
                    abilities = await self.bot.get_available_abilities(hq)
                    if AbilityId.EFFECT_CHRONOBOOSTENERGYCOST in abilities:
                        self.bot.microActions.append(hq(AbilityId.EFFECT_CHRONOBOOSTENERGYCOST, ccore))
                        self.coreboosted = True
                        return

            # Boost Gateway
            if self.bot.units(UnitTypeId.GATEWAY).ready.exists and self.bot.units(UnitTypeId.CYBERNETICSCORE).ready.exists:
                gw = self.bot.units(UnitTypeId.GATEWAY).ready.first
                if not gw.has_buff(BuffId.CHRONOBOOSTENERGYCOST):
                    abilities = await self.bot.get_available_abilities(hq)
                    if AbilityId.EFFECT_CHRONOBOOSTENERGYCOST in abilities:
                        self.bot.microActions.append(hq(AbilityId.EFFECT_CHRONOBOOSTENERGYCOST, gw))
                        return

            # Boost Warpgate
            if self.bot.units(UnitTypeId.WARPGATE).ready.exists and self.bot.units(UnitTypeId.CYBERNETICSCORE).ready.exists:
                warps = self.bot.units(UnitTypeId.WARPGATE).ready.first
                if not warps.has_buff(BuffId.CHRONOBOOSTENERGYCOST):
                    abilities = await self.bot.get_available_abilities(hq)
                    if AbilityId.EFFECT_CHRONOBOOSTENERGYCOST in abilities:
                        self.bot.microActions.append(hq(AbilityId.EFFECT_CHRONOBOOSTENERGYCOST, warps))
                        return

    async def createWall(self):
        """Wall-in Routine"""
        await self.bot.ressources.createGas()

        rampsupplybuildposition = self.bot.ramp_location
        rampsupply = self.bot.units.structure.filter(lambda w: w.type_id == UnitTypeId.PYLON).closer_than(5, rampsupplybuildposition)

        if rampsupply:
            self.ramp_supply_built = True
        else:
            self.ramp_supply_built = False
            await self.bot.unitmanager.createSupply(rampsupplybuildposition, 0, True)

        if self.ramp_supply_built:
            depot_placement_positions = self.bot.main_base_ramp.corner_depots | {self.bot.main_base_ramp.depot_in_middle}

            depots = self.bot.units(UnitTypeId.PHOTONCANNON)

            if depots:
                depot_placement_positions = {d for d in depot_placement_positions if depots.closest_distance_to(d) > 3}

            if len(depot_placement_positions) == 0:
                return
            target_depot_location = depot_placement_positions.pop()
            await self.bot.unitmanager.createBuilding("PhotonCannon", 2, target_depot_location, 0, True)

            if depots.ready:
                await self.bot.unitmanager.createBuilding("ShieldBattery", 1, rampsupplybuildposition, 7, True)