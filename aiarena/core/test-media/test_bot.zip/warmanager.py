from sc2.client import *
from sc2.constants import *
import random

class WarManager():
    def __init__(self, bot=None):
        self.bot = bot

        self.commander = False
        self.commanderunit = None
        self.commanderposition = False
        self.commandertarget = None
        self.attack_count = 0
        self.retreat_count = 3
        self.startcounter = False
        self.fightstarted = False
        self.move2ramp = False
        self.bot.expansion = False

        self.enemy_status_older = None
        self.enemy_status = None
        self.my_status_older = None
        self.my_status = None
        self.startcounter = None

        self.enemy_armypower_older = None
        self.enemy_armypower = None

        self.workerscout = None
        self.bot.scout_tag = None
        self.workerguard = None
        self.mineral_worker = None

    async def Run(self):
        await self.estimate()
        await self.estimate_status()
        await self.check_retreat()
        await self.counterattack()
        await self.commanderroutine()
        await self.fightroutine()
        await self.defendroutine()
        await self.counterworkerrush()

        if int(self.bot.time) <= 300:
            self.attack_count = 5
        elif int(self.bot.time) >= 300:
            self.attack_count = 10
        elif int(self.bot.time) >= 600:
            self.attack_count = 15

        if self.bot.iteration & 2 == 0:
            await self.estimate()
            await self.estimate_status()

        if self.bot.showstatus:
            if int(self.bot.time) & 2 == 0:
                self.bot.gamemanager.clearscreen()
                print("My Army:             " + str(self.my_armypower) + "/" + str(self.attack_count))
                print("My Army (-30s):      " + str(self.my_armypower_older))
                print("My Status:           " + self.my_status)
                print("My Status (-30s):    " + self.my_status_older)

                print("Enemy Army:          " + str(self.enemy_armypower))
                print("Enemy Army (-30s):   " + str(self.enemy_armypower_older))
                print("Enemy Status:        " + self.enemy_status)
                print("Enemy Status (-30s): " + self.enemy_status_older)

    async def estimate(self):
        """Estimates the army value"""
        if int(self.bot.time) & 1 == 0:
            self.my_armypower = self.bot.units.not_structure.ready.amount - self.bot.workers.ready.amount

        if int(self.bot.time) & 25 == 0:
            self.my_armypower_older = self.my_armypower

        self.enemy_armypower = 0
        enemies = self.bot.known_enemy_units.not_structure.filter(lambda w: w.type_id not in [UnitTypeId.PROBE] and w.type_id not in [UnitTypeId.SCV] and w.type_id not in [UnitTypeId.DRONE])
        for e in enemies:
                self.enemy_armypower = self.enemy_armypower + 1

        if int(self.bot.time) & 25 == 0:
            self.enemy_armypower_older = self.enemy_armypower

        if self.enemy_armypower <= 0:
            self.enemy_armypower = 0

    async def estimate_status(self):
        """Estimates the status"""
        hqlist = self.bot.units(self.bot.townhall)
        hqpositions = []
        for n in hqlist:
            hqpositions.append(n.position)

        enemies = self.bot.known_enemy_units.not_structure.filter(lambda w: w.type_id not in [UnitTypeId.PROBE] and w.type_id not in [UnitTypeId.SCV] and w.type_id not in [UnitTypeId.DRONE])
        enemiesattacking = 0
        for e in enemies:
            for n in hqpositions:
                distance2hq = e.position.distance_to(n)
                if distance2hq <= 40:
                    enemiesattacking = enemiesattacking + 1

        if enemiesattacking >= 5:
            self.enemy_status = 'Attack'
        else:
            self.enemy_status = 'Unknown'

        # Provide output for my own Status
        if self.fightstarted:
            self.my_status = 'Attack'
        elif self.startcounter:
            self.my_status = 'Counter-Attack'
        else:
            self.my_status = 'Gather Units'

        if int(self.bot.time) & 25 == 0:
            self.enemy_status_older = self.enemy_status
            self.my_status_older = self.my_status

    async def counterattack(self):
        if self.bot.time >= 300:
            if (self.enemy_status_older == 'Attack' and self.enemy_status == 'Unknown') and (self.my_status != 'Attack' and self.my_armypower >= 8):
                self.startcounter = True
            elif self.my_armypower <= self.retreat_count:
                self.startcounter = False

    async def check_retreat(self):
        if self.my_armypower <= self.enemy_armypower:
            self.my_status = 'Retreat'
            fighters = self.bot.units.not_structure.ready.filter(
                lambda w: w.type_id not in [UnitTypeId.PROBE] and w.type_id not in [
                    UnitTypeId.OBSERVER] and w.type_id not in [UnitTypeId.WARPPRISM] and w.type_id not in [
                              UnitTypeId.WARPPRISMPHASING] and w.type_id not in [
                              UnitTypeId.DARKTEMPLAR] and w.type_id not in [UnitTypeId.OBSERVERSIEGEMODE])

            for fighter in fighters:
                distance2ramp = fighter.position.distance_to(self.bot.ramp_location)
                if distance2ramp >= 5:
                    self.bot.microActions.append(fighter.move(self.bot.ramp_location))

    async def counterworkerrush(self):
        fighters = self.bot.units.not_structure.filter(lambda w: w.type_id not in [self.bot.worker])
        enemyprobes = self.bot.known_enemy_units.not_structure.closer_than(30, self.bot.hq_location).filter(lambda w: w.type_id in [UnitTypeId.PROBE])
        if enemyprobes.amount >= 2 and not fighters:
            counterworkers = self.bot.units(self.bot.worker).ready
            mw = self.bot.units.find_by_tag(self.mineral_worker)
            if counterworkers:
                if mw:
                    counterworkers = counterworkers - [mw]
                else:
                    self.mineral_worker = counterworkers[0].tag
                    return

                for counterworker in counterworkers:
                    distance2hq = counterworker.position.distance_to(self.bot.hq_location)
                    if distance2hq <= 30:
                        next_enemy = enemyprobes.closest_to(counterworker)
                        self.bot.microActions.append(counterworker.attack(next_enemy))

        for worker in self.bot.units(self.bot.worker).ready:
            distance2hq = worker.position.distance_to(self.bot.hq_location)
            if distance2hq >= 30 and worker.is_attacking:
                self.bot.microActions.append(worker.move(self.bot.hq_location))

    async def commanderroutine(self):
        """Defines a Commander"""
        fighters = self.bot.units.not_structure.ready.filter(
            lambda w: w.type_id not in [self.bot.worker] and w.type_id not in [
                UnitTypeId.OBSERVER] and w.type_id not in [UnitTypeId.WARPPRISM] and w.type_id not in [
                            UnitTypeId.WARPPRISMPHASING] and w.type_id not in [UnitTypeId.DARKTEMPLAR] and w.type_id not in [UnitTypeId.SENTRY] and w.type_id not in [UnitTypeId.OBSERVERSIEGEMODE])

        if (fighters.amount > self.attack_count) or self.startcounter:
            self.fightstarted = True
        else:
            self.fightstarted = False

        if fighters:
            if not self.commander:
                    possiblecommanders = sorted(fighters, key=lambda i: i.distance_to(self.bot.enemy_start_locations[0]), reverse=False)
                    self.commander = possiblecommanders[0].tag
            else:
                for fighter in fighters:
                    if fighter.tag == self.commander:
                        #await self.bot._client.debug_text("C", fighter.position) # DEBUG
                        self.commanderunit = fighter
                        self.commanderposition = fighter.position
                        return
                self.commanderunit = None
                self.commander = False
                self.commandertarget = None
                return

    async def defendroutine(self):
        """Reacts to enemies around the Nexuses"""
        hqs = self.bot.units(UnitTypeId.NEXUS)
        for hq in hqs:
            enemies = self.bot.known_enemy_units.closer_than(30, hq)

            if enemies:
                self.attacked = True
                self.my_status = 'Defend'
                next_enemy = self.bot.known_enemy_units.closest_to(hq)

                fighters = self.bot.units.not_structure.ready.filter(
                    lambda w: w.type_id not in [UnitTypeId.PROBE] and w.type_id not in [
                        UnitTypeId.OBSERVER] and w.type_id not in [UnitTypeId.WARPPRISM] and w.type_id not in [
                                  UnitTypeId.WARPPRISMPHASING] and w.type_id not in [
                                  UnitTypeId.DARKTEMPLAR] and w.type_id not in [UnitTypeId.OBSERVERSIEGEMODE])

                for fighter in fighters:
                    self.bot.microActions.append(fighter.attack(next_enemy.position))
            else:
                self.attacked = False

    async def fightroutine(self):
        """The main Attack and Movement Routine"""
        if not self.commander or not self.commanderunit or not self.commanderposition:
            return

        fighters = self.bot.units.not_structure.ready.filter(
            lambda w: w.type_id not in [self.bot.worker] and w.type_id not in [
                UnitTypeId.OBSERVER] and w.type_id not in [UnitTypeId.WARPPRISM] and w.type_id not in [
                            UnitTypeId.WARPPRISMPHASING] and w.type_id not in [UnitTypeId.DARKTEMPLAR])
        if fighters:
            for fighter in fighters:

                # Commander Action
                if fighter.tag == self.commander:

                    if not self.fightstarted:
                        d = random.randint(0, 4)
                        rampdistance = fighter.position.distance_to(self.bot.main_base_ramp.top_center.position)
                        checkpointposition = self.bot.main_base_ramp.top_center.position.towards(self.bot._game_info.player_start_location, d)
                        checkpointdistance = fighter.position.distance_to(checkpointposition)

                        if self.move2ramp:
                            if rampdistance < 2:
                                self.move2ramp = False
                                break
                            else:
                                self.bot.microActions.append(fighter.move(self.bot.main_base_ramp.top_center.position.towards(self.bot._game_info.player_start_location, d)))
                        elif not self.move2ramp:
                            if checkpointdistance < 2:
                                self.move2ramp = True
                                break
                            else:
                                if not self.bot.in_pathing_grid(checkpointposition):
                                    return
                                self.bot.microActions.append(fighter.move(checkpointposition))

                    elif self.fightstarted:
                        # Target
                        if self.bot.known_enemy_structures:
                            target = random.choice(self.bot.known_enemy_structures).position
                        elif self.bot.known_enemy_units:
                            target = random.choice(self.bot.known_enemy_units).position
                        else:
                            target = None

                        squad = self.bot.units.not_structure.ready.filter(
                            lambda w: w.type_id not in [self.bot.worker] and w.type_id not in [
                                UnitTypeId.OBSERVER] and w.type_id not in [UnitTypeId.WARPPRISM] and w.type_id not in [
                                          UnitTypeId.WARPPRISMPHASING] and w.type_id not in [UnitTypeId.DARKTEMPLAR]).closer_than(10, fighter)

                        if squad.amount < 6:
                            self.bot.microActions.append(fighter.move(fighter.position))
                            break

                        if target:
                            self.bot.microActions.append(fighter.attack(target.position))
                            self.commanderposition = target.position
                            self.commandertarget = target.position
                            break
                        else:
                            self.commandertarget = None
                            ramp = self.bot.main_base_ramp.top_center
                            hq = self.bot.units(self.bot.townhall).first
                            p = ramp.position.towards(hq.position, 1)
                            distance = fighter.position.distance_to(p)
                            if distance < 2:
                                break
                            self.bot.microActions.append(fighter.attack(p))
                            self.commanderposition = p
                            break

                # Fighter Action
                elif fighter.tag != self.commander:
                    await self.moveroutine(fighter)


    async def moveroutine(self, fighterunit):
        """Orders the given unit to move next to the Commander"""
        if self.commanderunit:
            distance = fighterunit.position.distance_to(self.commanderposition)
            if distance < 3:
                return
            target = self.commandertarget
            if not target:
                pos = self.commanderposition.towards(fighterunit.position, random.randrange(1, 3))
                if not self.bot.in_pathing_grid(pos):
                    return
            else:
                pos = self.commanderposition.towards(target, random.randrange(3, 10))
                if not self.bot.in_pathing_grid(pos):
                    return

            if self.fightstarted:
                self.bot.microActions.append(fighterunit.attack(pos))
            else:
                self.bot.microActions.append(fighterunit.attack(pos))
        else:
            return

    async def expand(self):
        if self.bot.already_pending(self.bot.townhall):
            self.bot.expansion = False
            return
        if self.bot.can_afford(self.bot.townhall):
            location = await self.bot.get_next_expansion()
            if location:
                self.bot.expansion = True
                await self.bot.build(self.bot.townhall, location)

    async def scout(self, unit=False, corners=False, force=False):
        """Scouts for the enemy"""
        if self.bot.known_enemy_structures and not force:
            scout = self.bot.units.find_by_tag(self.bot.scout_tag)
            if scout:
                self.bot.microActions.append(scout.move(self.bot.units(self.bot.townhall).first.position))
                self.bot.scout_tag = None
                return
            else:
                return

        if not unit:
            unit = self.bot.units(self.bot.worker).ready.first
            if not unit:
                return

        scout = self.bot.units.find_by_tag(self.bot.scout_tag)
        if scout:
            return
        else:
            self.bot.scout_tag = unit.tag
            print("Scout: " + str(unit))
            for enemyStartLoc in list(self.bot.enemy_start_locations):
                if not corners:
                    self.bot.microActions.append(unit.move(enemyStartLoc.position, queue=True))
                    self.bot.microActions.append(unit.move(self.bot.state.mineral_field.random.position, queue=True))
                else:
                    if self.bot.startpoint == 'SW':
                        self.bot.microActions.append(unit.move(self.bot.mapcorner_se, queue=True))
                        self.bot.microActions.append(unit.move(self.bot.mapcorner_ne, queue=True))
                        self.bot.microActions.append(unit.move(enemyStartLoc.position, queue=True))
                        self.bot.microActions.append(unit.move(self.bot.state.mineral_field.random.position, queue=True))
                    if self.bot.startpoint == 'SE':
                        self.bot.microActions.append(unit.move(self.bot.mapcorner_sw, queue=True))
                        self.bot.microActions.append(unit.move(self.bot.mapcorner_nw, queue=True))
                        self.bot.microActions.append(unit.move(enemyStartLoc.position, queue=True))
                        self.bot.microActions.append(unit.move(self.bot.state.mineral_field.random.position, queue=True))
                    if self.bot.startpoint == 'NW':
                        self.bot.microActions.append(unit.move(self.bot.mapcorner_ne, queue=True))
                        self.bot.microActions.append(unit.move(self.bot.mapcorner_se, queue=True))
                        self.bot.microActions.append(unit.move(enemyStartLoc.position, queue=True))
                        self.bot.microActions.append(unit.move(self.bot.state.mineral_field.random.position, queue=True))
                    if self.bot.startpoint == 'NE':
                        self.bot.microActions.append(unit.move(self.bot.mapcorner_nw, queue=True))
                        self.bot.microActions.append(unit.move(self.bot.mapcorner_sw, queue=True))
                        self.bot.microActions.append(unit.move(enemyStartLoc.position, queue=True))
                        self.bot.microActions.append(unit.move(self.bot.state.mineral_field.random.position, queue=True))
