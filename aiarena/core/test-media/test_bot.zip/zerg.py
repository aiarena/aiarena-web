from sc2.constants import *


class ZergManager():
    def __init__(self, bot=None):
        self.bot = bot
        self.workerscout = None

    async def Run(self):
        await self.Macro()
        await self.Micro()
        await self.Buffs()

    async def Macro(self):
        await self.bot.ressources.createGas()
        await self.bot.unitmanager.createUnit("Zergling", 5)
        await self.bot.unitmanager.createUnit("Hydralisk", 5)
        await self.bot.unitmanager.createUnit("Mutalisk", 5)
        await self.bot.unitmanager.createUnit("Ravager", 5)
        await self.bot.unitmanager.createUnit("Queen", 5)

        # Send a worker scout
        if self.bot.units(self.bot.worker).ready and not self.workerscout:
            worker = self.bot.units(self.bot.worker).ready.first
            if worker:
                self.workerscout = True
                await self.bot.warmanager.scout(worker)

        # Check if expansion is needed
        if (self.bot.units(self.bot.worker).ready.amount / 1.1) >= self.bot.neededworkers:
            await self.bot.warmanager.expand()

        if int(self.bot.time) >= 300 and self.bot.units(self.bot.townhall).amount == 1:
            await self.bot.warmanager.expand()
        if int(self.bot.time) >= 600 and self.bot.units(self.bot.townhall).amount <= 3:
            await self.bot.warmanager.expand()


    async def Micro(self):
        # Queen
        queens = self.bot.units(UnitTypeId.QUEEN).ready
        if queens:
            for queen in queens:
                enemies = self.bot.known_enemy_units.closer_than(30, queen)

                if enemies:
                    next_enemy = enemies.closest_to(queen)
                    if not next_enemy:
                        break

                    distance2enemy = queen.position.distance_to(next_enemy.position)
                    if distance2enemy < 20:
                        self.bot.microActions.append(queen.attack(next_enemy))

                    nx = self.bot.townhalls.ready.closest_to(queen)
                    if not nx:
                        break

                    nxdistance = queen.position.distance_to(nx.position)
                    if nxdistance < 10:
                        break

                    if distance2enemy < self.bot.techtree.get_unit_weaponrange(UnitTypeId.QUEEN):
                        if (next_enemy.name != 'Probe') or (next_enemy.name != 'SCV') or (
                                next_enemy.name != 'Drone'):
                            if distance2enemy < 2:
                                break
                            else:
                                moveposition = queen.position.towards(next_enemy.position, -1)
                                if not moveposition or not self.bot.in_pathing_grid(moveposition):
                                    break
                                self.bot.microActions.append(queen.move(moveposition))

    async def Buffs(self):
        return
