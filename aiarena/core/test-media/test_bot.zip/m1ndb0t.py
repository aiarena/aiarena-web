import sc2
from sc2.client import *
from techtree import *
from ressources import *
from gamemanager import *
from unitmanager import *
from warmanager import *
from protoss import *
from terran import *
from zerg import *

class m1ndb0t(sc2.BotAI):
    def __init__(self):
        super().__init__()
        self.techtree = TechTree(self)
        self.ressources = Ressources(self)
        self.gamemanager = GameManager(self)
        self.unitmanager = UnitManager(self)
        self.warmanager = WarManager(self)
        self.protossmanager = ProtossManager(self)
        self.terranmanager = TerranManager(self)
        self.zergmanager = ZergManager(self)
        self.iteration = None

        self.showstatus = False

    async def on_step(self, iteration):
        """Runs on every Gamestep"""
        if iteration == 0:
            await self.gamemanager.startGame()

        self.iteration = iteration

        # Manage own and enemy Race
        await self.gamemanager.manageRaces()
        await self.ressources.manageSupply()

        # Persistent data: Attack Time
        if self.opponent_id:
            datafile = "./data/" + self.opponent_id + ".db"
            if not os.path.isfile(datafile):
                await self.gamemanager.dataAttacktime()
            else:
                await self.gamemanager.readdata(self.opponent_id)

        # TAGGING
        for unit in self.units.not_structure.ready:
            if unit.tag not in self.unitInfo:
                self.unitInfo[unit.tag] = {'worker': 0, 'scout': 0, 'type': 'unit'}

        # Manage Workers
        await self.ressources.manageWorkers()

        # Race Specific Actions
        if self.race_self == 'Protoss':
            await self.protossmanager.Run()
        elif self.race_self == 'Terran':
            await self.terranmanager.Run()
        elif self.race_self == 'Zerg':
            await self.zergmanager.Run()

        # War
        await self.warmanager.Run()

        # Kamikaze
        hq = self.townhalls
        if not hq:
            target = self.known_enemy_structures.random_or(self.enemy_start_locations[0]).position
            for unit in self.workers | self.units.not_structure:
                self.microActions.append(unit.attack(target))
                return

        # Perform microActions
        await self.do_actions(self.microActions)
        self.microActions.clear()
