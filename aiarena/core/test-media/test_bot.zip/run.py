import sc2, sys
from __init__ import run_ladder_game
from sc2 import Race, Difficulty
from sc2.player import Bot, Computer
from m1ndb0t import m1ndb0t

bot = Bot(Race.Protoss, m1ndb0t())

import os.path

def log_to_data():
    datafile = "./data/test.txt"
    count = 0

    if os.path.isfile(datafile):
        file = open(datafile, "r")
        count = int(file.read())
        file.close()

    count = count+1

    file = open(datafile, "w")
    file.write(str(count))
    file.close()

# Start game
if __name__ == '__main__':
    log_to_data()
    if "--LadderServer" in sys.argv:
        # Ladder game started by LadderManager
        print("Starting ladder game...")
        run_ladder_game(bot)
    else:
        # Local game
        print("Starting local game...")
        sc2.run_game(sc2.maps.get("AutomatonLE"), [
            bot,
            Computer(Race.Protoss, Difficulty.Harder)
        ], realtime=False)
