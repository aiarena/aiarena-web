from sc2.client import *
from sc2.constants import *
import random


class UnitManager():
    def __init__(self, bot=None):
        self.bot = bot

    async def trainSkill(self, skillname):
        """Builds everything required for an Abiltiy"""
        skillid = self.bot.techtree.get_id_from_name(skillname)
        trainbuilding = self.bot.techtree.get_trainBuilding(skillname)
        if not self.bot.units(trainbuilding).exists:
            buildingname = self.bot.techtree.get_name_from_id(trainbuilding.value)
            await self.createBuilding(buildingname, 1, self.bot.hq_location)
        else:
            if self.bot.can_afford(AbilityId(skillid)):
                if self.bot.units(trainbuilding).ready:
                    tb = self.bot.units(trainbuilding).ready.first
                    self.bot.microActions.append(tb(AbilityId(skillid)))

    async def createUnit(self, unitname, count):
        """Builds everything required to Train a Unit / Trains a Unit"""
        trainbuilding = self.bot.techtree.get_trainBuilding(unitname)
        trainunittype = self.bot.techtree.get_id_from_name(unitname)
        supplycost = self.bot.techtree.get_supplycost(unitname)
        unitcount = self.bot.units(trainunittype).amount
        unitrequirement = self.bot.techtree.get_unit_buildRequirement(unitname)

        # Build a Supply if we dont have enough for a given Unit
        if self.bot.supply_left < supplycost:
            await self.bot.ressources.manageSupply()

        if unitcount < count:
            if trainbuilding:
                if self.bot.can_afford(trainunittype):

                    # Protoss specific
                    if self.bot.race_self == 'Protoss' and trainbuilding.name == 'GATEWAY':
                        if self.bot.units(UnitTypeId.WARPGATE).ready:
                            if self.bot.units(UnitTypeId.WARPGATE).ready.idle:
                                trainstructure = self.bot.units(UnitTypeId.WARPGATE).ready.idle.first
                                abilities = await self.bot.get_available_abilities(trainstructure)
                                if AbilityId.WARPGATETRAIN_STALKER in abilities:
                                    pylon = self.bot.units(UnitTypeId.PYLON).closest_to(trainstructure)
                                    pos = pylon.position.to2.random_on_distance(4)
                                    if pos:
                                        possible_positions = {pos + Point2((x, y)) for x in range(-5, 6) for y in range(-5, 6)}
                                        better_positions = pos.sort_by_distance(possible_positions)
                                        for placement in better_positions:
                                            if placement:
                                                if self.bot.in_placement_grid(placement) and self.bot.is_visible(placement):
                                                    self.bot.microActions.append(trainstructure.warp_in(trainunittype, placement))

                        else:
                            # If the train building does not exist - build it
                            if self.bot.units(trainbuilding).ready.idle:
                                trainstructure = self.bot.units(trainbuilding).ready.idle.first
                                self.bot.microActions.append(trainstructure.train(trainunittype))

                    elif unitname == 'Observer':
                        observers = self.bot.units(UnitTypeId.OBSERVER).ready
                        observersiege = self.bot.units(UnitTypeId.OBSERVERSIEGEMODE).ready
                        allobservers = observers | observersiege
                        if allobservers:
                            print("allobservers: " + str(allobservers.amount))
                            if allobservers.amount >= count:
                                return

                    else:
                        if self.bot.units(trainbuilding).ready.idle:
                            trainstructure = self.bot.units(trainbuilding).ready.idle.first
                            print("Training: " + str(unitname))
                            self.bot.microActions.append(trainstructure.train(trainunittype))

                if self.bot.units(trainbuilding).exists:
                    if unitrequirement:
                        for requirement in unitrequirement:
                            buildingid = None
                            if 'building' in requirement:
                                buildingid = UnitTypeId(requirement['building'])
                            elif 'addon' in requirement:
                                buildingid = UnitTypeId(requirement['addon'])
                            buildingname = self.bot.techtree.get_name_from_id(buildingid.value)
                            await self.createBuilding(buildingname, 1, self.bot.hq_location)

                else:
                    trainbuildingid = trainbuilding.value
                    trainbuildingname = self.bot.techtree.get_name_from_id(trainbuildingid)
                    await self.createBuilding(trainbuildingname, 1, self.bot.hq_location)

    async def createSupply(self, position, maxrange=8, force=False):
        """Creates Supply"""
        buildingname = self.bot.techtree.get_supplyBuilding()
        buildingid = self.bot.techtree.get_id_from_name(buildingname)
        building = UnitTypeId(buildingid)

        # Return if there is no worker available
        worker = self.bot.select_build_worker(position)
        if worker is None:
            return

        if not self.bot.already_pending(building) and self.bot.can_afford(building):
            if maxrange != 0:
                supplyposition = position.random_on_distance(random.randrange(1, maxrange))
            else:
                supplyposition = position

            # Make sure its not build close to the ramp
            supplypositionpositiondistancetoramp = supplyposition.distance_to(self.bot.ramp_location)
            if supplypositionpositiondistancetoramp < 10 and force is False:
                return

            # Return if its not in placement grid
            if not self.bot.in_placement_grid(supplyposition):
                return

            # Return if it cant be placed
            p = await self.bot.can_place(buildingid, supplyposition)
            if not p:
                return

            # Make sure its not build close to gas
            if self.bot.units(self.bot.gasbuilding).exists:
                gasbuildings = self.bot.units(self.bot.gasbuilding)
                nextgas = gasbuildings.closest_to(supplyposition)
                gas_distance2buildplace = nextgas.position.distance_to(supplyposition)
                if gas_distance2buildplace < 7 and force is False:
                    return

            # Make sure its not build close to mineras
            nextmineral = self.bot.state.mineral_field.closest_to(supplyposition)
            distance2buildplace = nextmineral.position.distance_to(supplyposition)
            if distance2buildplace > 7:
                print("Building supply: " + str(buildingname))
                self.bot.microActions.append(worker.build(building, supplyposition))

    async def createBuilding(self, buildingname, count, position, maxrange=15, force=False):
        """Builds everything required for a Building / Builds a Building"""
        buildingid = self.bot.techtree.get_id_from_name(buildingname)
        buildingcount = self.bot.units(buildingid).amount
        buildrequirement = self.bot.techtree.get_building_buildRequirement(buildingid)

        if buildingcount < count:
            if self.bot.can_afford(buildingid):
                # Check if there is a Requirement
                if buildrequirement:
                    for requirement in buildrequirement:
                        requirementbuildingid = UnitTypeId(requirement['building'])

                        # Create the required Building
                        if not self.bot.units(requirementbuildingid).exists:
                            if not self.bot.already_pending(requirementbuildingid):
                                requirementbuildingname = self.bot.techtree.get_name_from_id(requirementbuildingid.value)
                                await self.createBuilding(requirementbuildingname, 1, self.bot.hq_location, 15)
                                return

                # Return if there is no worker available
                worker = self.bot.select_build_worker(position)
                if worker is None:
                    return

                if maxrange != 0:
                    randomposition = position.random_on_distance(random.randrange(1, maxrange))
                else:
                    randomposition = position

                # Return if its not in placement grid
                if not self.bot.in_placement_grid(randomposition):
                    return

                # Return if it cant be placed
                p = await self.bot.can_place(buildingid, randomposition)
                if not p:
                    return

                # Protoss specific - Make sure Buildings a created around a Pylon Pos.
                if self.bot.race_self == 'Protoss' and force is False:
                    pylons = self.bot.units(UnitTypeId.PYLON).ready
                    if pylons:
                        for pylon in pylons:
                            for hq in self.bot.units(self.bot.townhall):
                                # Make sure we dont build at a Proxy Pylon
                                if pylon.position.distance_to(hq.position) >= 20:
                                    return
                            randomposition = pylon.position.random_on_distance(random.randrange(1, 6))

                # Make sure there is some space to the next building
                closebuildings = self.bot.units.filter(lambda w: w.is_structure and w.distance_to(randomposition) <= 4)
                if closebuildings and force is False:
                    return

                # Make sure its not build close to the ramp
                randompositiondistancetoramp = randomposition.distance_to(self.bot.ramp_location)
                if randompositiondistancetoramp < 10 and force is False:
                    return

                # Make sure its not build close to mineras
                nextmineral = self.bot.state.mineral_field.closest_to(randomposition)
                mineral_distance2buildplace = nextmineral.position.distance_to(randomposition)
                if mineral_distance2buildplace < 7:
                    return

                # Make sure its not build close to gas
                if self.bot.units(self.bot.gasbuilding).exists:
                    gasbuildings = self.bot.units(self.bot.gasbuilding)
                    nextgas = gasbuildings.closest_to(randomposition)
                    gas_distance2buildplace = nextgas.position.distance_to(randomposition)
                    if gas_distance2buildplace < 4:
                        return

                # Protoss specific
                if self.bot.race_self == 'Protoss':
                    # Make sure Buildings a created in psyionic matrix
                    if not self.bot.state.psionic_matrix.covers(randomposition):
                        return

                    # Count Gateways/Warpgates
                    if buildingname == 'Gateway':
                        gatewaycount = 0
                        warpgatecount = 0
                        if self.bot.units(UnitTypeId.GATEWAY).exists:
                            gatewaycount = self.bot.units(UnitTypeId.GATEWAY).amount
                        if self.bot.units(UnitTypeId.WARPGATE).exists:
                            warpgatecount = self.bot.units(UnitTypeId.WARPGATE).amount
                        if (gatewaycount + warpgatecount) >= count:
                            return

                morphinfo = self.bot.techtree.get_building_morphbuilding(buildingid)
                if morphinfo:
                    # Buildings that are morphed
                    (morphbuildingid, morphability) = morphinfo
                    morphbuildingtype = UnitTypeId(morphbuildingid)
                    morphabilitytype = AbilityId(morphability)
                    morphbuilding = self.bot.units(morphbuildingtype).ready.first
                    if morphbuilding:
                        print("Morphing: " + str(buildingname))
                        await self.bot.do(morphbuilding(morphabilitytype))
                else:
                    # Buildings that are build
                    # await self.bot._client.debug_text("B", randomposition)  # DEBUG
                    print("Building: " + str(buildingname))
                    self.bot.microActions.append(worker.build(buildingid, randomposition))
