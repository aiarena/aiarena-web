from .main import MyBot
