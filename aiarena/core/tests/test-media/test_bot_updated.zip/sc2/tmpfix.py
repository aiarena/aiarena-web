# This file contains temporary fixes for issues already solved in the
# blizzard_internal branch of s2client-proto.
# These should be removed as soon as the changes are live and implemented.
#
# https://github.com/Blizzard/s2client-proto/tree/blizzard_internal
#
# NO OTHER CONTENT IS ALLOWED HERE
