from sc2.constants import *


class TerranManager():
    def __init__(self, bot=None):
        self.bot = bot
        self.ramp_supply_built = False
        self.workerscout = None

    async def Run(self):
        await self.Macro()
        await self.Micro()
        await self.Buffs()

    async def Macro(self):
        await self.bot.ressources.createGas()
        await self.createWall()
        await self.bot.unitmanager.createBuilding("Barracks", 4, self.bot.hq_location, 15)
        await self.bot.unitmanager.createUnit("Marine", 25)
        #await self.bot.unitmanager.createUnit("Cyclone", 5)
        await self.bot.unitmanager.createUnit("Medivac", 3)
        await self.bot.unitmanager.trainSkill("SCANNERSWEEP_SCAN")

        # Send a worker scout
        if self.bot.units(self.bot.worker).ready and not self.workerscout:
            worker = self.bot.units(self.bot.worker).ready.first
            if worker:
                self.workerscout = True
                await self.bot.warmanager.scout(worker)

        # Check if expansion is needed
        if (self.bot.units(self.bot.worker).ready.amount / 1.1) >= self.bot.neededworkers:
            await self.bot.warmanager.expand()

        if int(self.bot.time) >= 300 and self.bot.units(self.bot.townhall).amount == 1:
            await self.bot.warmanager.expand()
        if int(self.bot.time) >= 600 and self.bot.units(self.bot.townhall).amount <= 3:
            await self.bot.warmanager.expand()


    async def Micro(self):
        # Marine
        marines = self.bot.units(UnitTypeId.MARINE).ready
        if marines:
            for marine in marines:
                enemies = self.bot.known_enemy_units.closer_than(30, marine)

                if enemies:
                    next_enemy = enemies.closest_to(marine)
                    if not next_enemy:
                        break

                    distance2enemy = marine.position.distance_to(next_enemy.position)
                    if distance2enemy < 20:
                        self.bot.microActions.append(marine.attack(next_enemy))

                    nx = self.bot.townhalls.ready.closest_to(marine)
                    if not nx:
                        break

                    nxdistance = marine.position.distance_to(nx.position)
                    if nxdistance < 10:
                        break

                    if distance2enemy < self.bot.techtree.get_unit_weaponrange(UnitTypeId.MARINE):
                        if (next_enemy.name != 'Probe') or (next_enemy.name != 'SCV') or (
                                next_enemy.name != 'Drone'):
                            if distance2enemy < 2:
                                break
                            else:
                                moveposition = marine.position.towards(next_enemy.position, -1)
                                if not moveposition or not self.bot.in_pathing_grid(moveposition):
                                    break
                                self.bot.microActions.append(marine.move(moveposition))

        # Cyclone
        cyclones = self.bot.units(UnitTypeId.CYCLONE).ready
        if cyclones:
            for cyclone in cyclones:
                enemies = self.bot.known_enemy_units.closer_than(30, cyclone)

                if enemies:
                    next_enemy = enemies.closest_to(cyclone)
                    if not next_enemy:
                        break

                    distance2enemy = cyclone.position.distance_to(next_enemy.position)
                    if distance2enemy < 20:
                        self.bot.microActions.append(cyclone.attack(next_enemy))

                    nx = self.bot.townhalls.ready.closest_to(cyclone)
                    if not nx:
                        break

                    nxdistance = cyclone.position.distance_to(nx.position)
                    if nxdistance < 10:
                        break

                    if distance2enemy < self.bot.techtree.get_unit_weaponrange(UnitTypeId.cyclone):
                        if (next_enemy.name != 'Probe') or (next_enemy.name != 'SCV') or (
                                next_enemy.name != 'Drone'):
                            if distance2enemy < 2:
                                break
                            else:
                                moveposition = cyclone.position.towards(next_enemy.position, -1)
                                if not moveposition or not self.bot.in_pathing_grid(moveposition):
                                    break
                                self.bot.microActions.append(cyclone.move(moveposition))


    async def Buffs(self):
        # Supply Depots
        # Raise depos when enemies are nearby
        for depo in self.bot.units(UnitTypeId.SUPPLYDEPOT).ready:
            for unit in self.bot.known_enemy_units.not_structure:
                if unit.position.to2.distance_to(depo.position.to2) < 15:
                    break
            else:
                await self.bot.do(depo(AbilityId.MORPH_SUPPLYDEPOT_LOWER))

        # Lower depos when no enemies are nearby
        for depo in self.bot.units(UnitTypeId.SUPPLYDEPOTLOWERED).ready:
            for unit in self.bot.known_enemy_units.not_structure:
                if unit.position.to2.distance_to(depo.position.to2) < 10:
                    await self.bot.do(depo(AbilityId.MORPH_SUPPLYDEPOT_RAISE))
                    break

        # Scanner Sweep
        for hq in self.bot.townhalls.ready:
            abilities = await self.bot.get_available_abilities(hq)
            if AbilityId.SCANNERSWEEP_SCAN in abilities:
                self.bot.microActions.append(hq(AbilityId.SCANNERSWEEP_SCAN, self.bot.enemy_start_locations[0]))
                return

    async def createWall(self):
        depot_placement_positions = self.bot.main_base_ramp.corner_depots | {self.bot.main_base_ramp.depot_in_middle}

        depots = self.bot.units(UnitTypeId.SUPPLYDEPOT) | self.bot.units(UnitTypeId.SUPPLYDEPOTLOWERED)

        if depots:
            depot_placement_positions = {d for d in depot_placement_positions if depots.closest_distance_to(d) > 1}

        if self.bot.can_afford(UnitTypeId.SUPPLYDEPOT) and not self.bot.already_pending(UnitTypeId.SUPPLYDEPOT):
            if len(depot_placement_positions) == 0:
                return
            # Choose any depot location
            target_depot_location = depot_placement_positions.pop()
            ws = self.bot.workers.gathering
            if ws:  # if workers were found
                w = ws.random
                await self.bot.do(w.build(UnitTypeId.SUPPLYDEPOT, target_depot_location))